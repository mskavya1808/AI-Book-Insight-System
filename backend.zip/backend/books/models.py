from django.db import models

def generate_summary(text):
    return text[:100] + "..." if len(text) > 100 else text

def detect_genre(text):
    text = text.lower()
    if "magic" in text or "wizard" in text:
        return "Fantasy"
    elif "love" in text:
        return "Romance"
    elif "crime" in text:
        return "Thriller"
    elif "space" in text or "future" in text:
        return "Sci-Fi"
    else:
        return "General"

class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=200)
    description = models.TextField()
    summary = models.TextField(blank=True)
    genre = models.CharField(max_length=100, blank=True)

    def save(self, *args, **kwargs):
        if not self.summary:
            self.summary = generate_summary(self.description)
        if not self.genre:
            self.genre = detect_genre(self.description)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title