from django.urls import path
from .views import add_book, list_books

urlpatterns = [
    path('add/', add_book),
    path('list/', list_books),
]