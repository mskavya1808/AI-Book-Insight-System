from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Book
from .serializers import BookSerializer

# Simple AI logic (no API needed)
def generate_summary(text):
    return text[:100] + "..." if len(text) > 100 else text

def detect_genre(text):
    text = text.lower()
    if "magic" in text or "wizard" in text:
        return "Fantasy"
    elif "love" in text or "romance" in text:
        return "Romance"
    elif "crime" in text or "murder" in text:
        return "Thriller"
    elif "space" in text or "future" in text:
        return "Sci-Fi"
    else:
        return "General"

@api_view(['POST'])
def add_book(request):
    book = Book.objects.create(**request.data)

    # Generate summary
    book.summary = generate_summary(book.description)

    # Detect genre
    book.genre = detect_genre(book.description)

    book.save()

    return Response(BookSerializer(book).data)

@api_view(['GET'])
def list_books(request):
    books = Book.objects.all()
    return Response(BookSerializer(books, many=True).data)